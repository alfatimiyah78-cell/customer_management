<?php
/* Smarty version 4.5.3, created on 2025-10-02 02:04:15
  from 'C:\xampp\htdocs\phpnuxbill\ui\ui\sections\footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_68dd7b2f2f5823_09232486',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '30ab07dacaa26b510c5d5c494ee7b5d20c8fcb58' => 
    array (
      0 => 'C:\\xampp\\htdocs\\phpnuxbill\\ui\\ui\\sections\\footer.tpl',
      1 => 1742442232,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:admin/footer.tpl' => 1,
  ),
),false)) {
function content_68dd7b2f2f5823_09232486 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:admin/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
