<?php
/* Smarty version 4.5.3, created on 2025-10-02 02:04:09
  from 'C:\xampp\htdocs\phpnuxbill\ui\ui\widget\info_payment_gateway.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_68dd7b2916aa47_30088113',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3db9d95631324e56fda7f1a571272b101b33a913' => 
    array (
      0 => 'C:\\xampp\\htdocs\\phpnuxbill\\ui\\ui\\widget\\info_payment_gateway.tpl',
      1 => 1742442232,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_68dd7b2916aa47_30088113 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="panel panel-success panel-hovered mb20 activities">
    <div class="panel-heading"><?php echo Lang::T('Payment Gateway');?>
: <?php echo str_replace(',',', ',$_smarty_tpl->tpl_vars['_c']->value['payment_gateway']);?>

    </div>
</div><?php }
}
