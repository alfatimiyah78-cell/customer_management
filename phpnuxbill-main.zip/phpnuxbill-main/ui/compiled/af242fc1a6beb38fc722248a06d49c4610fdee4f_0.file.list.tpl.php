<?php
/* Smarty version 4.5.3, created on 2025-10-02 21:38:34
  from 'C:\xampp\htdocs\phpnuxbill\ui\ui\admin\voucher\list.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_68de8e6a75f377_86934635',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'af242fc1a6beb38fc722248a06d49c4610fdee4f' => 
    array (
      0 => 'C:\\xampp\\htdocs\\phpnuxbill\\ui\\ui\\admin\\voucher\\list.tpl',
      1 => 1742442232,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:sections/header.tpl' => 1,
    'file:pagination.tpl' => 1,
    'file:sections/footer.tpl' => 1,
  ),
),false)) {
function content_68de8e6a75f377_86934635 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:sections/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
<!-- voucher -->
<div class="row" style="padding: 5px">
    <div class="col-lg-3 col-lg-offset-9">
        <div class="btn-group btn-group-justified" role="group">
            <div class="btn-group" role="group">
                <a href="<?php echo Text::url('');?>
plan/add-voucher" class="btn btn-primary"><i class="ion ion-android-add"></i>
                    <?php echo Lang::T('Vouchers');?>
</a>
            </div>
            <div class="btn-group" role="group">
                <a href="<?php echo Text::url('');?>
plan/print-voucher" target="print_voucher" class="btn btn-info"><i
                        class="ion ion-android-print"></i> <?php echo Lang::T('Print');?>
</a>
            </div>
        </div>
    </div>
</div>
<div class="panel panel-hovered mb20 panel-primary">
    <div class="panel-heading">
        <?php if (in_array($_smarty_tpl->tpl_vars['_admin']->value['user_type'],array('SuperAdmin','Admin'))) {?>
            <div class="btn-group pull-right">
                <a class="btn btn-danger btn-xs" title="Remove used Voucher" href="<?php echo Text::url('');?>
plan/remove-voucher"
                    onclick="return ask(this, 'Delete all used voucher code more than 3 months?')"><span
                        class="glyphicon glyphicon-trash" aria-hidden="true"></span> <?php echo Lang::T('Delete');?>
 &gt; <?php echo Lang::T('3
                Months');?>
</a>
            </div>
        <?php }?>
        &nbsp;
    </div>
    <div class="panel-body">
        <form id="site-search" method="post" action="<?php echo Text::url('');?>
plan/voucher/">
            <div class="row" style="padding: 5px">
                <div class="col-lg-2">
                    <div class="input-group">
                        <div class="input-group-addon">
                            <span class="fa fa-search"></span>
                        </div>
                        <input type="text" name="search" class="form-control" placeholder="<?php echo Lang::T('Code Voucher');?>
"
                            value="<?php echo $_smarty_tpl->tpl_vars['search']->value;?>
">
                    </div>
                </div>
                <div class="col-lg-2">
                    <select class="form-control" id="router" name="router">
                        <option value=""><?php echo Lang::T('Location');?>
</option>
                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['routers']->value, 'r');
$_smarty_tpl->tpl_vars['r']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['r']->value) {
$_smarty_tpl->tpl_vars['r']->do_else = false;
?>
                            <option value="<?php echo $_smarty_tpl->tpl_vars['r']->value;?>
" <?php if ($_smarty_tpl->tpl_vars['router']->value == $_smarty_tpl->tpl_vars['r']->value) {?>selected<?php }?>><?php echo $_smarty_tpl->tpl_vars['r']->value;?>

                            </option>
                        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                    </select>
                </div>
                <div class="col-lg-2">
                    <select class="form-control" id="plan" name="plan">
                        <option value=""><?php echo Lang::T('Plan Name');?>
</option>
                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['plans']->value, 'p');
$_smarty_tpl->tpl_vars['p']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['p']->value) {
$_smarty_tpl->tpl_vars['p']->do_else = false;
?>
                            <option value="<?php echo $_smarty_tpl->tpl_vars['p']->value['id'];?>
" <?php if ($_smarty_tpl->tpl_vars['plan']->value == $_smarty_tpl->tpl_vars['p']->value['id']) {?>selected<?php }?>><?php echo $_smarty_tpl->tpl_vars['p']->value['name_plan'];?>
</option>
                        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                    </select>
                </div>
                <div class="col-lg-2">
                    <select class="form-control" id="status" name="status">
                        <option value="-"><?php echo Lang::T('Status');?>
</option>
                        <option value="1" <?php if ($_smarty_tpl->tpl_vars['status']->value == 1) {?>selected<?php }?>>Used</option>
                        <option value="0" <?php if ($_smarty_tpl->tpl_vars['status']->value == 0) {?>selected<?php }?>>Not Use</option>
                    </select>
                </div>
                <div class="col-lg-2">
                    <select class="form-control" id="customer" name="customer">
                        <option value=""><?php echo Lang::T('Customer');?>
</option>
                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['customers']->value, 'c');
$_smarty_tpl->tpl_vars['c']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['c']->value) {
$_smarty_tpl->tpl_vars['c']->do_else = false;
?>
                            <option value="<?php echo $_smarty_tpl->tpl_vars['c']->value['user'];?>
" <?php if ($_smarty_tpl->tpl_vars['customer']->value == $_smarty_tpl->tpl_vars['c']->value['user']) {?>selected<?php }?>><?php echo $_smarty_tpl->tpl_vars['c']->value['user'];?>
</option>
                        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                    </select>
                </div>
                <div class="col-lg-2">
                    <div class="btn-group btn-group-justified" role="group">
                        <div class="btn-group" role="group">
                            <button class="btn btn-success btn-block" type="submit"><span
                                    class="fa fa-search"></span></button>
                        </div>
                        <div class="btn-group" role="group">
                            <a class="btn btn-warning btn-block" title="Clear Search Query"
                                href="<?php echo Text::url('');?>
plan/voucher/"><span
                                    class="glyphicon glyphicon-remove-circle"></span></a>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <div class="table-responsive">
        <div style="margin-left: 5px; margin-right: 5px;">&nbsp;
            <table id="datatable" class="table table-bordered table-striped table-condensed">
                <thead>
                    <tr>
                        <th><input type="checkbox" id="select-all"></th>
                        <th>ID</th>
                        <th><?php echo Lang::T('Type');?>
</th>
                        <th><?php echo Lang::T('Routers');?>
</th>
                        <th><?php echo Lang::T('Plan Name');?>
</th>
                        <th><?php echo Lang::T('Code Voucher');?>
</th>
                        <th><?php echo Lang::T('Status Voucher');?>
</th>
                        <th><?php echo Lang::T('Customer');?>
</th>
                        <th><?php echo Lang::T('Create Date');?>
</th>
                        <th><?php echo Lang::T('Used Date');?>
</th>
                        <th><?php echo Lang::T('Generated By');?>
</th>
                        <th><?php echo Lang::T('Manage');?>
</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['d']->value, 'ds');
$_smarty_tpl->tpl_vars['ds']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['ds']->value) {
$_smarty_tpl->tpl_vars['ds']->do_else = false;
?>
                        <tr <?php if ($_smarty_tpl->tpl_vars['ds']->value['status'] == '1') {?>class="danger" <?php }?>>
                            <td><input type="checkbox" name="voucher_ids[]" value="<?php echo $_smarty_tpl->tpl_vars['ds']->value['id'];?>
"></td>
                            <td><?php echo $_smarty_tpl->tpl_vars['ds']->value['id'];?>
</td>
                            <td><?php echo $_smarty_tpl->tpl_vars['ds']->value['type'];?>
</td>
                            <td><?php echo $_smarty_tpl->tpl_vars['ds']->value['routers'];?>
</td>
                            <td><?php echo $_smarty_tpl->tpl_vars['ds']->value['name_plan'];?>
</td>
                            <td style="background-color: black; color: black;"
                                onmouseleave="this.style.backgroundColor = 'black';"
                                onmouseenter="this.style.backgroundColor = 'white';">
                                <?php echo $_smarty_tpl->tpl_vars['ds']->value['code'];?>
</td>
                            <td><?php if ($_smarty_tpl->tpl_vars['ds']->value['status'] == '0') {?> <label class="btn-tag btn-tag-success"> Not Use
                                </label> <?php } else { ?> <label class="btn-tag btn-tag-danger">Used</label>
                                <?php }?></td>
                            <td><?php if ($_smarty_tpl->tpl_vars['ds']->value['user'] == '0') {?> -
                                <?php } else { ?><a href="<?php echo Text::url('');?>
customers/viewu/<?php echo $_smarty_tpl->tpl_vars['ds']->value['user'];?>
"><?php echo $_smarty_tpl->tpl_vars['ds']->value['user'];?>
</a>
                                <?php }?></td>
                            <td><?php if ($_smarty_tpl->tpl_vars['ds']->value['created_at']) {
echo Lang::dateTimeFormat($_smarty_tpl->tpl_vars['ds']->value['created_at']);
}?></td>
                            <td><?php if ($_smarty_tpl->tpl_vars['ds']->value['used_date']) {
echo Lang::dateTimeFormat($_smarty_tpl->tpl_vars['ds']->value['used_date']);
}?></td>
                            <td><?php if ($_smarty_tpl->tpl_vars['ds']->value['generated_by']) {?>
                                    <a
                                        href="<?php echo Text::url('');?>
settings/users-view/<?php echo $_smarty_tpl->tpl_vars['ds']->value['generated_by'];?>
"><?php echo $_smarty_tpl->tpl_vars['admins']->value[$_smarty_tpl->tpl_vars['ds']->value['generated_by']];?>
</a>
                                <?php } else { ?> -
                                <?php }?>
                            </td>
                            <td>
                                <?php if ($_smarty_tpl->tpl_vars['ds']->value['status'] != '1') {?>
                                    <a href="<?php echo Text::url('');?>
plan/voucher-view/<?php echo $_smarty_tpl->tpl_vars['ds']->value['id'];?>
" id="<?php echo $_smarty_tpl->tpl_vars['ds']->value['id'];?>
" style="margin: 0px;"
                                        class="btn btn-success btn-xs">&nbsp;&nbsp;<?php echo Lang::T('View');?>
&nbsp;&nbsp;</a>
                                <?php }?>
                                <?php if (in_array($_smarty_tpl->tpl_vars['_admin']->value['user_type'],array('SuperAdmin','Admin'))) {?>
                                    <a href="<?php echo Text::url('');?>
plan/voucher-delete/<?php echo $_smarty_tpl->tpl_vars['ds']->value['id'];?>
" id="<?php echo $_smarty_tpl->tpl_vars['ds']->value['id'];?>
"
                                        class="btn btn-danger btn-xs" onclick="return ask(this, '<?php echo Lang::T('Delete');?>
?')"><i
                                            class="glyphicon glyphicon-trash"></i></a>
                                <?php }?>
                            </td>
                        </tr>
                    <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<div class="row" style="padding: 5px">
    <div class="col-lg-3 col-lg-offset-9">
        <div class="btn-group btn-group-justified" role="group">
            <div class="btn-group" role="group">
                <?php if (in_array($_smarty_tpl->tpl_vars['_admin']->value['user_type'],array('SuperAdmin','Admin'))) {?>
                    <button id="deleteSelectedVouchers" class="btn btn-danger"><?php echo Lang::T('Delete
                    Selected');?>
</button>
                <?php }?>
            </div>
        </div>
    </div>
</div>
<?php $_smarty_tpl->_subTemplateRender("file:pagination.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php echo '<script'; ?>
>
    function deleteVouchers(voucherIds) {
        if (voucherIds.length > 0) {
            Swal.fire({
                title: 'Are you sure?',
                text: 'You won\'t be able to revert this!',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    var xhr = new XMLHttpRequest();
                    xhr.open('POST', '<?php echo Text::url('');?>
plan/voucher-delete-many', true);
                    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                    xhr.onload = function() {
                        if (xhr.status === 200) {
                            var response = JSON.parse(xhr.responseText);

                            if (response.status === 'success') {
                                Swal.fire({
                                    title: 'Deleted!',
                                    text: response.message,
                                    icon: 'success',
                                    confirmButtonText: 'OK'
                                }).then(() => {
                                    location.reload(); // Reload the page after confirmation
                                });
                            } else {
                                Swal.fire({
                                    title: 'Error!',
                                    text: response.message,
                                    icon: 'error',
                                    confirmButtonText: 'OK'
                                });
                            }
                        } else {
                            Swal.fire({
                                title: 'Error!',
                                text: 'Failed to delete vouchers. Please try again.',
                                icon: 'error',
                                confirmButtonText: 'OK'
                            });
                        }
                    };
                    xhr.send('voucherIds=' + JSON.stringify(voucherIds));
                }
            });
        } else {
            Swal.fire({
                title: 'Error!',
                text: 'No vouchers selected to delete.',
                icon: 'error',
                confirmButtonText: 'OK'
            });
        }
    }

    // Example usage for selected vouchers
    document.getElementById('deleteSelectedVouchers').addEventListener('click', function() {
        var selectedVouchers = [];
        document.querySelectorAll('input[name="voucher_ids[]"]:checked').forEach(function(checkbox) {
            selectedVouchers.push(checkbox.value);
        });

        if (selectedVouchers.length > 0) {
            deleteVouchers(selectedVouchers);
        } else {
            Swal.fire({
                title: 'Error!',
                text: 'Please select at least one voucher to delete.',
                icon: 'error',
                confirmButtonText: 'OK'
            });
        }
    });

    document.querySelectorAll('.delete-voucher').forEach(function(button) {
        button.addEventListener('click', function() {
            var voucherId = this.getAttribute('data-id');
            deleteVouchers([voucherId]);
        });
    });


    // Select or deselect all checkboxes
    document.getElementById('select-all').addEventListener('change', function() {
        var checkboxes = document.querySelectorAll('input[name="voucher_ids[]"]');
        for (var checkbox of checkboxes) {
            checkbox.checked = this.checked;
        }
    });
<?php echo '</script'; ?>
>
<?php $_smarty_tpl->_subTemplateRender("file:sections/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
