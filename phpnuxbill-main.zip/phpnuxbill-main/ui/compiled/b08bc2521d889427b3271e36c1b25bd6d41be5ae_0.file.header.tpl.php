<?php
/* Smarty version 4.5.3, created on 2025-10-02 02:04:13
  from 'C:\xampp\htdocs\phpnuxbill\ui\ui\sections\header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_68dd7b2d24c1c9_99364326',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b08bc2521d889427b3271e36c1b25bd6d41be5ae' => 
    array (
      0 => 'C:\\xampp\\htdocs\\phpnuxbill\\ui\\ui\\sections\\header.tpl',
      1 => 1742442232,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:admin/header.tpl' => 1,
  ),
),false)) {
function content_68dd7b2d24c1c9_99364326 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:admin/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php }
}
