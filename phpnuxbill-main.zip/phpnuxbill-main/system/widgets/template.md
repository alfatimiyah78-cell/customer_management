<?php





```php
class widget_name
{

    public static getWidget($data)
    {
        global $config, $ui;

        return $ui->fetch('widget/template');
    }
}
```
